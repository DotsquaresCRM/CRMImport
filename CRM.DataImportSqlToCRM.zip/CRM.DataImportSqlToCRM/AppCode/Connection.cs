﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSTools.SqlToCRMImport.AppCode
{
    public static class Connection
    {
        public static string ConnectionString;
        public static string UserID;
        public static string Password;
        public static string ServerName;
        public static string Database;
    }
}
